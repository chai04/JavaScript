# js-algorithms
Computer science

> If you like this project, follow me on Twitter [@bliashenko](https://twitter.com/bliashenko) to hear about things I am building.

Algorithms list:
- Hash table
- Linked list
- Stack
- Queue
- Bubble sort
- Binary search
- Breadth first search
- Depth first search
- Small tasks
